# @Time     : 2020/9/11 
# @Author   :  Leo
from flask import(
    Blueprint,
    render_template,
    views,
    request,
    redirect,
    url_for,
    session,
    jsonify,
    g
)
from .response_code import RET
from datetime import datetime
from utils import restful
import logging
from . import constants
from .models import Order, User, Charge
from exts import db
from apps.cms.models import ChargeModel, CarModel
front_bp = Blueprint('', __name__, url_prefix='/')


@front_bp.route('/', methods=["GET"])
def index():
    """
    查询charge简介 
    :return:
    """
    # print(session.get('user_id'))
    charges = ChargeModel.query.all()
    context = {
        "charges": charges,
    }
    return render_template('front/index.html', **context)


@front_bp.route('/detail/<int:house_id>')
def post_detail(post_id):
    post = Charge.query.get(post_id)
    if not post_id:
        return restful.params_error(message="帖子不存在")
    print(post)
    return render_template("front/front_detail.html")
