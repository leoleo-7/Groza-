#!/usr/bin/env python
# _*_ coding:  utf-8  _*_
# @Time  :  2020/1/8 
# @Author:  Leo
from flask import request, redirect, session, url_for, g
from .views import cms_bp
from .models import CMSUser
# 通过钩子函数


@cms_bp.before_request
def before_request():
    # if not request
    # request.url或者request.path都可以得到 http://127.0.0.1:1010/cms/login/
    print(request.url)
    # endswith判断是否以cms.login结尾
    if not request.path.endswith(url_for('cms.login')):
        user_id = session.get('user_id')
        if not user_id:
            return redirect(url_for('cms.login'))

    if 'user_id' in session:
        user_id = session.get('user_id')
        user = CMSUser.query.get(user_id)
        # print(user)
        if user:
            g.cms_user = user