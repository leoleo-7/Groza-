# @Time     : 2020/9/11 
# @Author   :  Leo
from flask import(
    Blueprint,
    render_template,
    views,
    request,
    redirect,
    url_for,
    session,
    jsonify,
    g
)
from .forms import LoginForm, AddChargeForm, UpdateChargeForm
from .models import CMSUser,ChargeModel,CarModel,OrderModel
from apps.front.models import User
from sqlalchemy import or_
from exts import db
from utils import restful


cms_bp = Blueprint('cms', __name__, url_prefix='/cms')
# hooks需要cms_bp
from .hooks import before_request


@cms_bp.route('/')
def index():
    print(session.get('user_id'))
    return render_template('cms/cms_index.html')
    # return 'cms_index'/


@cms_bp.route('/profile/')
def profile():
    return render_template('cms/cms_profile.html')


@cms_bp.route('/logout/')
def logout():
    # 删除session user_id
    # 重定向 登陆页面
    del session['user_id']
    return redirect(url_for('cms.login'))


class LoginView(views.MethodView):
    def get(self, message=None):
        return render_template('cms/cms_login.html', message=message)

    def post(self):
        login_form = LoginForm(request.form)
        if login_form.validate():
            # 数据库验证邮箱密码是否正确
            email_user = login_form.email_user.data
            password = login_form.password.data
            remember = login_form.remember.data
            # user = CMSUser.query.filter_by(email=email_user).first()
            user = CMSUser.query.filter(or_(CMSUser.username == email_user, CMSUser.email == email_user)).first()
            # username = CMSUser.query.filter_by(usernam=username).first()
            # print(user)
            if user and user.check_password(password):
                session['user_id'] = user.id
                # session['user_name'] = user.username
                if remember:
                    session.permanent = True
                # 登陆成功 跳转首页
                return redirect(url_for('cms.index'))
            else:
                # return render_template('cms/cms_login.html', message="邮箱或者密码错误")
                return self.get(message="邮箱或者密码错误")
        else:
            # .popitem()将字典变成元组
            # print(login_form.errors.popitem()[1][0])
            # return "表单验证错误"
            return self.get(message=login_form.get_error())


@cms_bp.route("/fusers/")
def fusers():
    users = User.query.all()
    return render_template("cms/cms_fusers.html", users=users)


@cms_bp.route("/cars/")
def cars():
    cars = CarModel.query.all()
    return render_template("cms/cms_cars.html", cars=cars)


@cms_bp.route("/charges/")
def charges():
    charges = ChargeModel.query.all()
    return render_template("cms/cms_charges.html", charges=charges)


@cms_bp.route("/order/")
def orders():
    orders = OrderModel.query.order_by(OrderModel.orderid).all()
    print(orders)
    return render_template("cms/cms_order.html", orders=orders)


# 添加


@cms_bp.route('/abanner/', methods=['POST'])
def abanner():
    form = AddChargeForm(request.form)
    if form.validate():
        name = form.name.data
        image_url = form.image_url.data

        charge=ChargeModel(name=name, image_url=image_url)
        db.session.add(charge)
        db.session.commit()
        return restful.success()
    else:
        return restful.params_error(message=form.get_error())

# 修改


@cms_bp.route('/ubanner/', methods=['POST'])
def ubanners():
    form = UpdateChargeForm(request.form)
    if form.validate():
        charge_id = form.charge_id.data
        name = form.name.data
        image_url = form.image_url.data
        banner = ChargeModel.query.get(charge_id)
        if banner:
            banner.name = name
            banner.image_url = image_url
            db.session.commit()
            return restful.success()
        else:
            return restful.params_error(message='充电桩不存在')
    else:
        return restful.params_error(message=form.get_error())


@cms_bp.route('/dbanner/', methods=['POST'])
def dbanner():
    banner_id = request.form.get('banner_id')
    if not banner_id:
        return restful.params_error(message='轮播图不存在')
    # .query.get方法: 返回指定主键对应的行，如不存在，返回None
    banner = ChargeModel.query.get(banner_id)
    # print(banner)
    # print(Banner.is_delete)
    if banner:
        # 更新数据库表中得数据
        ChargeModel.query.filter_by(id=banner.id).update({'is_delete': 1})
        db.session.commit()
        return restful.success()
    else:
        return restful.params_error('轮播图不存在')


cms_bp.add_url_rule("/login", view_func=LoginView.as_view('login'))