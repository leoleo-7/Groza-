from exts import db
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash


class CMSUser(db.Model):
    __tabletime__ = 'user'
    id =db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(50), nullable=False, unique=True)
    # 改200 因为加密长度50不够
    join_time = db.Column(db.DateTime, default=datetime.now)
    _password = db.Column(db.String(200), nullable=False)

    def __init__(self, username, password):
        self.username = username
        self.password = password

    # 设置访问密码的方法,并用装饰器@property设置为属性,调用时不用加括号
    @property
    def password(self):
        return self._password

    # 设置加密的方法,传入密码,对类属性进行操作
    @password.setter
    def password(self, raw_password):
        self._password = generate_password_hash(raw_password)

    def check_password(self, raw_password):
        result = check_password_hash(self.password, raw_password)
        return result


class CarModel(db.Model):
    __tabletime__ = 'car'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    carname = db.Column(db.String(50), nullable=False)
    charge_id = db.Column(db.Integer, db.ForeignKey('charge.id'))
    join_time = db.Column(db.DateTime, default=datetime.now)

    charge = db.relationship("ChargeModel", backref='cars')


class ChargeModel(db.Model):
    __tablename__ = 'charge'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    chargename = db.Column(db.String(50), nullable=False)
    detail = db.Column(db.String(50))
    join_time = db.Column(db.DateTime, default=datetime.now)


class OrderModel(db.Model):
    __tablename__ = 'order'
    ordename = db.Column(db.String(50), nullable=False)
    orderid = db.Column(db.Integer, primary_key=True, autoincrement=True)
    price = db.Column(db.Float)
    charge_id = db.Column(db.Integer, db.ForeignKey("charge.id"))
    car_id = db.Column(db.Integer, db.ForeignKey("car_model.id"))
    join_time = db.Column(db.DateTime, default=datetime.now)
    join_place = db.Column(db.String(50), nullable=False)

    charge = db.relationship("ChargeModel", backref='orders')
    car = db.relationship("CarModel", backref='orders')
