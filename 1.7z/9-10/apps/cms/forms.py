# @Time     : 2020/9/11 
# @Author   :  Leo
from wtforms import Form, StringField, IntegerField,  ValidationError
from wtforms.validators import Email, InputRequired, Length, EqualTo, ValidationError, URL
import re


class BaseForm(Form):
    def get_error(self):
        message = self.errors.popitem()[1][0]
        return message


def my_validators(form, field):
    if not re.match(r'(^\w+@\w+\.\w+)|(^[a-zA-Z]{2,10})', field.data):
        raise ValidationError('请输入正确的邮箱地址或用户名')


class LoginForm(BaseForm):
    email_user = StringField(validators=[my_validators, InputRequired(
        message='请输入邮箱或者用户名')])
    password = StringField(validators=[Length(4, 20, message='请输入正确格式的密码')])
    remember = IntegerField()


class AddChargeForm(BaseForm):
    name = StringField(validators=[InputRequired(message="请输入充电桩名称")])
    image_url = StringField(validators=[InputRequired(message="请输入充电桩图片链接"), URL(message="图片链接有误")])


class UpdateChargeForm(AddChargeForm):
    banner_id = IntegerField(validators=[InputRequired(message="充电桩不存在")])


class AddBoardsForm(BaseForm):
    name = StringField(validators=[InputRequired(message="请输入板块名称")])


class UpdateBoardsForm(AddBoardsForm):
    board_id = IntegerField(validators=[InputRequired(message="请输入正确的ID")])