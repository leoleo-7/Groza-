import pymysql as  pm
class Mysql_connect:
   
    #获取数据连接
    def getConn(self,):
        return pm.connect("localhost", "root", "root", "test")

    # 建立数据库语句执行接口
    def execute(self,SQL):
        conn = self.getConn()
        cursor = conn.cursor(cursor=pm.cursors.DictCursor)
        # type = SQL.split(" ")[0]
        # print(type)
        cursor.execute(SQL) 
        conn.commit()
        result = cursor.fetchall()
        return result


