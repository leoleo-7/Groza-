#!/usr/bin/env python
# _*_ coding:  utf-8  _*_
# @Time  :  2020/1/8 
# @Author:  Leo
from flask_script import Manager
import random
from flask_migrate import Migrate, MigrateCommand
from exts import db
from test import app
# 导入模型
# 映射哪个模型，就把哪个模型导入进来
from apps.cms.models import CMSUser, CarModel, ChargeModel, OrderModel
from apps.front.models import User, Charge, Order

manage = Manager(app)

# 第一个参数是Flask的实例，第二个参数是Sqlalchemy数据库实例
Migrate(app, db)
manage.add_command('db', MigrateCommand)


@manage.option('-u', '--username', dest='username')
@manage.option('-p', '--password', dest='password')
@manage.option('-e', '--email', dest='email')
def create_cms_user(username, password, email):
    user = CMSUser(username=username, password=password, email=email)
    db.session.add(user)
    db.session.commit()
    print('cms用户添加成功')


# @manage.option('-t', '--telephone', dest='telephone')
@manage.option('-u', '--username', dest='username')
@manage.option('-p', '--password', dest='password')
def create_front_user(username, password):
    user = User(username=username, password=password)
    db.session.add(user)
    db.session.commit()
    print('front用户添加成功')


if __name__ == '__main__':  
    manage.run()
