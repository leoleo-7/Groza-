-- MySQL dump 10.13  Distrib 8.0.11, for macos10.13 (x86_64)
--
-- Host: localhost    Database: testDB
-- ------------------------------------------------------
-- Server version	8.0.11
	drop database testDB;
	create database
	if not exists testDB;
	use testDB;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Asalas`
--

DROP TABLE IF EXISTS `Asalas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `Asalas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(32) NOT NULL,
  `contract_id` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `checkCarTime` varchar(32) NOT NULL,
  `GetCarTime` varchar(32) NOT NULL,
  `GetCarLPTime` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Asalas`
--

LOCK TABLES `Asalas` WRITE;
/*!40000 ALTER TABLE `Asalas` DISABLE KEYS */;
/*!40000 ALTER TABLE `Asalas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract`
--

DROP TABLE IF EXISTS `contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `contract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(32) NOT NULL,
  `order_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `is_insure` varchar(32) NOT NULL,
  `total` varchar(32) NOT NULL,
  `createDate` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract`
--

LOCK TABLES `contract` WRITE;
/*!40000 ALTER TABLE `contract` DISABLE KEYS */;
INSERT INTO `contract` VALUES (28,'1',41,'张三_福特(进口)-Mustang_合约','是','36.985',NULL),(29,'1',63,'礼物_大众(进口)-途锐_合约','是','56.980.005','2020-6-27');
/*!40000 ALTER TABLE `contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `lead` varchar(32) NOT NULL,
  `member` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (8,'总经理办公室','总经理','总经理助手'),(9,'人力资源部','HR经理','HR'),(11,'技术支持部','技术总监','员工'),(12,'市场营销部','经理','员工'),(13,'安全监察部','经理','员工'),(14,'财务部','财务总监','会计');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `WorkingDays` varchar(32) NOT NULL,
  `basicSalary` varchar(32) NOT NULL,
  `salary` varchar(32) NOT NULL,
  `PIncomeTax` varchar(32) NOT NULL,
  `aTaxIncome` varchar(32) NOT NULL,
  `department` varchar(32) NOT NULL,
  `position` varchar(32) NOT NULL,
  `title` varchar(32) NOT NULL,
  `img` varchar(2083) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (32,'张三','22','10000','8800.00','170','8630','总经理办公室','总经理助手','高级',''),(33,'张三','20','10000','8000.00','90','7910','总经理办公室','总经理助手','高级',''),(34,'张三','200','10000','80000.00','19090','60910','总经理办公室','总经理助手','高级',''),(35,'张三','22','10000','8800.00','170','8630','总经理办公室','总经理','高级',''),(36,'李四','22','10000','8800.00','170','8630','人力资源部','HR经理','高级',''),(37,'王五','323','10000','12000','490','11510','财务部','财务总监','高级',''),(38,'王六','323','10000','12000','490','11510','技术支持部','技术总监','高级',''),(39,'王七','323','10000','12000','490','11510','市场营销部','经理','高级',''),(40,'王八','323','10000','12000','490','11510','安全监察部','经理','高级',''),(41,'王八','323','10000','12000','490','11510','安全监察部','员工','高级',''),(42,'王八','323','10000','12000','490','11510','其他部门','经理','高级',''),(50,'张三','222','10000','12000','490','11510','市场营销部','员工','高级',''),(51,'张三','222','10000','12000','490','11510','财务部','会计','高级',''),(52,'张三','222','10000','12000','490','11510','人力资源部','HR','高级',''),(53,'张三','222','10000','12000','490','11510','技术支持部','员工','高级','');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` varchar(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `number` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `status` varchar(32) NOT NULL,
  `total` varchar(32) NOT NULL,
  `createDate` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (63,'64',1,'1','礼物_大众(进口)-途锐','待售后','56.98','2020-06-26'),(64,'64',1,'1','礼物_大众(进口)-途锐','待付款','56.98','2020-06-30'),(65,'64',1,'1','礼物_大众(进口)-途锐','待付款','56.98','2020-06-30'),(66,'64',2,'2','张三_大众(进口)-途锐','待付款','113.96','2020-05-26'),(67,'64',2,'2','张三_大众(进口)-途锐','待付款','113.96','2020-05-26'),(68,'64',2,'2','张三_大众(进口)-途锐','待付款','113.96','2020-05-26'),(69,'64',2,'2','张三_大众(进口)-途锐','待付款','113.96','2020-04-26'),(70,'64',2,'2','张三_大众(进口)-途锐','待付款','113.96','2020-04-26'),(71,'64',2,'2','张三_大众(进口)-途锐','待付款','113.96','2020-04-26'),(72,'64',2,'2','张三_大众(进口)-途锐','待付款','113.96','2020-04-26'),(73,'64',2,'2','张三_大众(进口)-途锐','待付款','113.96','2020-03-26'),(74,'64',2,'2','张三_大众(进口)-途锐','待付款','113.96','2020-03-26'),(75,'64',2,'2','张三_大众(进口)-途锐','待付款','113.96','2020-03-26'),(76,'64',2,'1','张三_大众(进口)-途锐','待付款','56.98','2020-02-26'),(77,'64',2,'1','张三_大众(进口)-途锐','待付款','56.98','2020-02-26'),(78,'64',2,'1','张三_大众(进口)-途锐','待付款','56.98','2020-02-26'),(79,'64',2,'1','张三_大众(进口)-途锐','待付款','56.98','2019-01-26'),(80,'64',2,'1','张三_大众(进口)-途锐','待付款','56.98','2019-01-26'),(81,'64',2,'1','张三_大众(进口)-途锐','待付款','56.98','2019-01-26'),(82,'64',2,'1','张三_大众(进口)-途锐','待付款','56.98','2019-01-26'),(83,'64',2,'1','张三_大众(进口)-途锐','待付款','56.98','2019-01-26'),(84,'64',2,'1','张三_大众(进口)-途锐','待付款','56.98','2019-01-26'),(85,'64',2,'1','张三_大众(进口)-途锐','待付款','56.98','2019-01-26'),(86,'64',2,'1','张三_大众(进口)-途锐','待付款','56.98','2019-01-26'),(87,'64',2,'1','张三_大众(进口)-途锐','待付款','56.98','2019-01-26'),(88,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-06-26'),(89,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-06-26'),(90,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-06-26'),(91,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-06-26'),(92,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-06-26'),(93,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-06-26'),(94,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-06-26'),(95,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-05-26'),(96,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-05-26'),(97,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-06-26'),(98,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-06-26'),(99,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-04-26'),(100,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-04-26'),(101,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-03-26'),(102,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-03-26'),(103,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-02-26'),(104,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-02-26'),(105,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-02-26'),(106,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-02-26'),(107,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-01-26'),(108,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-01-26'),(109,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-01-26'),(110,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2020-01-26'),(111,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2019-01-29'),(112,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2019-01-29'),(113,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2019-02-28'),(114,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2019-01-28'),(115,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2019-01-28'),(116,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2019-02-28'),(117,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2019-03-28'),(118,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2019-03-28'),(119,'59',1,'1','礼物_东风悦达起亚-智跑','待付款','14.49','2019-04-28'),(120,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-02-28'),(121,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-02-28'),(122,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-02-28'),(123,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-02-28'),(124,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-02-28'),(125,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-02-28'),(126,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-02-28'),(127,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-02-28'),(128,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-02-28'),(129,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-02-28'),(130,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-02-28'),(131,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-02-28'),(132,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-03-28'),(133,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-05-28'),(134,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-05-28'),(135,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-06-28'),(136,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-06-28'),(137,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-06-28'),(138,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-06-28'),(139,'57',1,'1','礼物_一汽-大众-迈腾','待付款','18.61','2019-07-28');
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(32) NOT NULL,
  `storeNumber` varchar(32) NOT NULL,
  `category` varchar(32) NOT NULL,
  `brand` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `img` varchar(2083) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (57,'18.61','10000','轿车类','大众','一汽-大众-迈腾','http://img1.xcarimg.com/b2/s12093/20191226093505629382983374680.jpg-280x210.jpg'),(58,'9.99','1000','轿车类','大众','上汽大众-Polo','http://img1.xcarimg.com/PicLib/s/s11238_300.jpg'),(59,'14.49','1000','轿车类','起亚','东风悦达起亚-智跑','http://img1.xcarimg.com/PicLib/s/s11568_300.jpg'),(61,'29.39','1000','轿车类','宝马','华晨宝马-宝马3系','http://img1.xcarimg.com/PicLib/s/s11952_300.jpg'),(62,'36.98','1000','跑车','福特','福特(进口)-Mustang','http://img1.xcarimg.com/PicLib/s/s11418_300.jpg'),(63,'12.89','1111','轿车类','大众','一汽-大众-速腾','http://img1.xcarimg.com/PicLib/s/s13205_300.jpg'),(64,'56.98','1111','轿车类','大众','大众(进口)-途锐','http://img1.xcarimg.com/PicLib/s/s13098_300.jpg');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `passwd` varchar(32) NOT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `profile_photo` varchar(2083) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'root','礼物','root','17743242465','/static/img/profilePhoto/7406E122-88DE-4D6D-91F1-68EF2DD992CA.jpeg'),(2,'admiin','张三','root','17362452564','undefined'),(3,'root2','账务','root','13544352443','https://static.easyicon.net/preview/124/1246828.gif');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-02 15:46:47
