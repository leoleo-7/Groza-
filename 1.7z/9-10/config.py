# 数据库连接配置

import cymysql, os

HOSTNAME = '127.0.0.1'
DATABASE = 'test'
PORT = 3306
USERNAME = 'root'
PASSWORD = 'root'

DB_URL = 'mysql+cymysql://{}:{}@{}:{}/{}?charset=utf8'.format(USERNAME, PASSWORD,
                                                                     HOSTNAME, PORT, DATABASE)

# engine = create_engine(DB_URL)
SQLALCHEMY_DATABASE_URI = DB_URL
SQLALCHEMY_TRACK_MODIFICATIONS = False

SECRET_KEY = 'lsq'
# 发送邮箱的服务地址
MAIL_SERVER = 'smtp.qq.com'
MAIL_PORT = 587
MAIL_USE_TLS = True
# MAIL_USE_SSL: default False 465

MAIL_USERNAME = '864407737@qq.com'
MAIL_PASSWORD = 'zjrwgryouktqbfcg'
MAIL_DEFAULT_SENDER = '864407737@qq.com'

PER_PAGE = 10

# CELERY_BROKER_URL = "redis://127.0.0.1/0"
# CELERY_RESULT_BACKEND = "redis://127.0.0.1/0"