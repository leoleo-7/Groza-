from flask import Flask, url_for, request, render_template, redirect, make_response
from mysql_connect import Mysql_connect
import os, base64, sys, string, json
from jinja2 import Markup, Environment, FileSystemLoader
from pyecharts.globals import CurrentConfig
# from pyecharts.charts import Line, Pie
# import pyecharts.options as opts
# import numpy as np
# import config
# from exts import db
#
CurrentConfig.ONLINE_HOST = 'http://127.0.0.1:8080/static/js/'
CurrentConfig.GLOBAL_ENV = Environment(loader=FileSystemLoader("./static/pyechartsHTML"))
#
# app = Flask(__name__)
mc = Mysql_connect()
#
# app.config.from_object(config)
# db.init_app(app)
#
#
# class Test:
#     # 页面的控制
#     @app.route("/<filename>", methods =["GET"])
#     def render(filename):
#         f = "%s.html" % filename
#         dirs = os.listdir('./templates')
#         print(filename)
#         if (f not in dirs):
#             return ''
#         # filename=  'index' if filename=='favicon.ico' else filename
#         return render_template(f)
#
#     # 数据接口
#     # @app.route("/api/renderData/", methods=["POST"])
#     # def render_data():
#     #     sql = request.form['sql']
#     #
#     #     return {"data": mc.execute(sql)}
#
#     @app.route("/", methods=["get", "post"])
#     # 首页
#     def index():
#         return render_template("index.html")
#
#
# if __name__ == "__main__":
#     app.run(debug=True, port=8080)


from flask import Flask
from exts import db, mail
from apps.cms.views import cms_bp
from apps.front.views import front_bp
# from apps.common.views import common_bp
import config
from flask_wtf import CSRFProtect


app = Flask(__name__)

csrf = CSRFProtect(app)

app.config.from_object(config)

db.init_app(app)
mail.init_app(app)

#页面控制

@app.route("/<filename>", methods=["GET"])
# @csrf.exempt
def render(filename):
    f = "%s.html" % filename
    dirs = os.listdir('./templates')
    print(filename)
    if (f not in dirs):
        return ''
    # filename=  'index' if filename=='favicon.ico' else filename
    return render_template(f)


# 数据接口
@app.route("/api/renderData/", methods=["POST"])
# @csrf.exempt
def render_data():
    sql = request.form['sql']
    print(sql)
    return {"data": mc.execute(sql)}


app.register_blueprint(cms_bp)
app.register_blueprint(front_bp)
# app.register_blueprint(common_bp)


if __name__ == '__main__':
    app.run(port=1010, debug=True)

