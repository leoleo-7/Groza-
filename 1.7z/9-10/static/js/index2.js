let nav = new Vue({
    el: "#app",
    delimiters: ['[[', ']]'],

    data: {

        user: {
            "id": "",
            "uname": "",
            "name": "",
            "passwd": "",
            "phone": "",
            "profile_photo": ""
        },

    },
    methods: {
        render_data(sql) {
            let FD = new FormData();
            FD.append("sql", sql)
            return axios.post("/api/renderData/", FD).catch(err => {
                console.error(err);
            });

        },

        loadData(table) {
            let uname = document.cookie.split('=')[1];
            if (this.is_login && table != "product") {
                if (table == 'order') {
                    let sql =
                        "select  o.*,u.uname u_uname,p.* from `order` as o inner join product as p on(o.product_id = p.id) inner join user as u on(o.user_id = u.id) where u.id=%1 and (o.status!='已售后' and o.status!='待付款');"
                            .replace('%1', this.user.id);
                    console.log(sql);

                    this.render_data(sql).then(res => {
                        this[table] = res.data['data'];
                        console.log('order', this[table], this[table].length);
                        this.orderLength = this[table].length;

                    });
                    return;
                }
                if (table == 'user') {
                    let sql = "select * from %0 where uname='%1' or phone='%1'".replace(/%1/g, uname)
                        .replace('%0', table);
                    console.log(sql);
                    this.render_data(sql).then(res => {
                        this[table] = table == 'user' ? res['data']['data'][0] : res.data['data'];

                    })
                }
                if (table == 'contract' || table == 'Asalas') {
                    console.log(this.user.id);
                    let sql = "select * from %1 where user_id='%2'".replace('%1', table).replace('%2', this.user.id);
                    console.log(sql);
                    this.render_data(sql).then(res => {
                        this[table] = res.data.data;
                        // console.log('contract|Asalas',this[table],this[table].length);

                        // this.orderLength=this.orderLength+this[table].length;

                    })
                }
            }
            if (table == "product") {
                this.render_data("select * from product").then(res => {
                    this[table] = res.data['data'];
                })


            }
        },


        getCurrentTime() {
            let date = new Date();
            // console.log(date.now.format("yyyy-MM-dd hh:mm:ss"));
            var time = [date.getFullYear(), '0' + (date.getMonth() + 1).toString(), date.getDate()].join('-');
            return time;
        }


    },
    mounted() {
        console.log(document.cookie);
        this.loadData('user');
        this.loadData('product');
        console.log(this.getCurrentTime());
        // this.getMyData();

        // console.log(document.forms['register']);
    },
    computed: {
        test() {
            this.loadData('order');
            this.loadData('contract');
            this.loadData('Asalas');

        },

    },


});