import nav from './nav.js'

nav.$mount("#nav");


var mvvm = new Vue({
    el: '#app',
    delimiters: ['[[', ']]'],

    data: {
        user_images: [
            "http://img.wxcha.com/file/201810/23/5e623a6c2f.jpeg",
            "https://pic4.zhimg.com/50/v2-e69b64ffc292924e50d8f3e65602e909_hd.jpg",
            "http://img.wxcha.com/file/201810/23/0086e071d0.jpeg",
        ],

        user: {
            "username": "",
            "passwd": "",
            "email": "",
            "profile_photo":""
        },
        type: "register",
        reg: {
            'username': /^\S{0,4}$/,
            'passwd': /^\S{0,4}$/,
        },
        alertinfos: {
            'username': "用户名不小于4位数",
            'passwd': "密码不小于4位数",
            "register": "用户已存在",
            "login": "用户名或密码错误"
        },
        request_url: {
            "register": "/api/has",
            "login": "/api/correct",
        }
    },
    computed: {
        usernameIsValid() {
            return this.reg['username'].test(this.user.username);
        },
        passwdIsValid() {
            return this.reg['passwd'].test(this.user.passwd);
        },
        // emailIsValid:function(){
        //     return this.reg['email'].test(this.email);
        // },

    },
    methods: {
        extends: nav,
        validateForm(e) {
            // 表单数据是否合法
            for (var k in this.reg) {
                if (this.reg[k].test(this.user.k)) {
                    alert(this.alertinfos[k]);

                }
            }
            // axios异步请求数据以验证表单数据是否存在
            axios.post(this.request_url[this.type], this.user)
                .then(res => {
                    console.log(res);
                    if (res.data.h)
                        alert(this.alertinfos[this.type]);
                    else
                        document.forms[this.type].submit();
                })
                .catch(err => {
                    console.error(err);
                })

        }


    },
    mounted() {},



});